add_lunch_combo aosp_seed-userdebug

