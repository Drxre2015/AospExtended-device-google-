/*
 * This file is automatic generated,
 * please do not make modification
 */

#ifdef __cplusplus
extern "C" {
#endif
const char* get_daemon_version(void);
const char* get_hal_version(void);
const char* get_build_date(void);
#ifdef __cplusplus
};
#endif
